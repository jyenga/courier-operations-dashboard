ORIGINAL DASHBOARD - DEPLOYMENT PACKAGE

index.html is an exact byte-for-byte copy of the original HTML in the uploaded ZIP, renamed only for static site hosting.

Warning: the dashboard embeds employee and operational records and photos. Public hosting makes those records accessible to anyone with the URL and potentially search engines. Do not deploy to public GitHub Pages unless you have authority to publish all embedded records. Prefer an access-controlled internal hosting environment.

For GitHub Pages: add index.html to repository root, Settings > Pages > Deploy from branch > main / root. This creates a public site URL typically https://USERNAME.github.io/REPOSITORY/ . Actual URL depends on account and settings.

Online CDN scripts/fonts are required for some features.
